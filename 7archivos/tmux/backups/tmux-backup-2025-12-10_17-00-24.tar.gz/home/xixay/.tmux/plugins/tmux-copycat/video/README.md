## Tmux copycat screencast

This directory contains docs used for creating
[tmux copycat screencast](https://vimeo.com/101867689).

- `script.md` - this file contains a script and a voiceover used to produce the
  screencast
