interval_option="@mighty-scroll-interval"
interval_default="2"

select_pane_option="@mighty-scroll-select-pane"
select_pane_default="on"

by_line_option="@mighty-scroll-by-line"
by_line_default="man less pager fzf"

by_page_option="@mighty-scroll-by-page"
by_page_default="irssi vi"

pass_through_option="@mighty-scroll-pass-through"
pass_through_default="vim nvim"

fallback_mode_option="@mighty-scroll-fallback-mode"
fallback_mode_default="history"

show_indicator_option="@mighty-scroll-show-indicator"
show_indicator_default="off"
